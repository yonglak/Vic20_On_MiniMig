This is a collection of cart images (mainly) the Final Expansion 3.
The collection has only been tried on a NTSC machine and Vice.

The quick start instructions.


Copy the contents of the sdcard directory into the root of your sd card and boot your vic and press f3.



All roms are in the roms directory and are splitup as need in the sdcard directory.

There is a loader file in the roms directory, But it requires a patched FE3 firmware to display correctly. 

You can find a patched version for use in vice in the instructions directory.

In this directory you will find the file "FullLoader In Text.txt"

This is a acsii version of the loader. Just chop up your roms and the loader as needed, they are in alphabetical order.
Just start vice, and mount the directory you want to save in, then copy from the text file 
and paste straight into basic with vice. Then save"loader",8

I recommend appending the following to the top of each sub menu.

10 "Return To Previous"
11 +@"cd//"
12 +reload

To use the roms directory under vice as one large one, load xvic.exe, set true drive emulation off, 
map the roms directory to drive 8 and then load the FEVer010-PatchedforLargeLoaders as a cart using the
attach as a Final Expansion Image.

Then just use f3 to get to the loader, and alt-r to reset back to the main menu.


I downloaded most of the games from zimmers, but also from a few other places on the web.
(Google is your friend)

Many thanks to everyone that worked so hard on the FE3.
Enjoy!

later,
dabone